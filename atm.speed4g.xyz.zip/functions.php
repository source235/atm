<?php
function getKey($paygate){
	$key = "";
	if($paygate == "momo")
		$key = "token";
	if($paygate == "paypal")
		$key = "secret_Key";
	if($paygate == "casso")
		$key = "api_Key";
	
	return $key;
}

function decrypt($crypted_token,$enc_key){
	$crypted_token = hex2bin($crypted_token);
	list($crypted_token, $enc_iv) = explode("::", $crypted_token);
	$cipher_method = 'aes-128-ctr';
	$token = openssl_decrypt($crypted_token, $cipher_method, $enc_key, 0, hex2bin($enc_iv));
	unset($crypted_token, $cipher_method, $enc_key, $enc_iv);
	
	return $token;
}