<html xmlns="http://www.w3.org/1999/xhtml">
    
    <head id="j_idt6">
        <meta charset="utf-8" />
        <meta http-equiv="x-ua-compatible" content="IE=edge" />
        <title>
            Thanh Toán - Paypal
        </title>
        <link
        href="https://billing.flypn.net/images/paypal.png"
        rel="icon"
        type="image/svg+xml"
        />
        <meta name="description" content="Cổng thanh toán qua Ví điện tử Paypal" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="robots" content="all,follow" />
        <meta http-equiv="cache-control" content="no-cache" />
        <meta http-equiv="expires" content="0" />
        <meta http-equiv="pragma" content="no-cache" />
        <!-- Bootstrap CSS-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha512-Dop/vW3iOtayerlYAqCgkVr2aTr2ErwwTYOvRFUpzl2VhCMJyjQF0Q9TjUXIo6JhuM/3i0vVEt2e/7QQmnHQqw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

        <!-- Google fonts - Roboto -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700"
        />
        <!-- theme stylesheet-->
        <link rel="stylesheet" href="css/style.default.css?version=<?php echo time();?>" id="theme-stylesheet" />
        <!-- Custom stylesheet - for your changes-->
        <link rel="stylesheet" href="css/style.css?version=<?php echo time();?>" />
        <link rel="stylesheet" href="css/qr-code.css?version=<?php echo time();?>" />
        <link rel="stylesheet" href="css/qr-code-tablet.css?version=<?php echo time();?>" />
      
        <!-- Font Awesome CDN-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.css" integrity="sha512-hwwdtOTYkQwW2sedIsbuP1h0mWeJe/hFOfsvNKpRB3CkRxq8EW7QMheec1Sgd8prYxGm1OM9OZcGW7/GUud5Fw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style type="text/css">
		
			
            .container-fluid {
				width: 40 % !important;
				min-width: 750px!important;
			}
			.info-box {
				min-height: 600px;
			}
			#page{
				padding: 50px 0;
			}
			.image-qr-code{
				max-width: 300px;
			}
			.note-box{
				background-color: #ffde4f;
				padding: 25px 15px;
				max-width: 400px;
				margin: 20px auto;
			}
			.code{
				font-weight: 700;
				color: red;
				font-size: 22px;
			}
			.code span{
				color: #5d5b5b;
				cursor: pointer;
			}
			.note-title{
				font-weight: 700;
				font-size: 18px;
				color: #3f3f3f;
				padding-bottom: 5px;
			}
			.momo-buttom{
				margin-bottom: 20px;
			}
			@media (max-height: 750px){
				#page {
					padding: 0;
				}
				.provider{
					margin-bottom: 10px;
				}
			}
			.sweet-alert h2{
				padding-top: 12px;
				font-size: 19px;
				text-transform: uppercase;
				font-weight: 700;
				color: #5cb85c;
			}
			.provider{
				margin-top: 19px;
				font-size: 10px;
				color: #b9b9b9;
				font-style: italic;
			}
			.provider a{
				color: #b9b9b9
			}
			.left {
				background-color: #003087;
				position: relative;
				padding-right: 0px;
				color: #ffffff;
			}
			.entry {
				border-bottom: 1px solid #3FA5B5;
				overflow: hidden;
				padding-top: 15px;
			}
			#status{
				text-align:center;
			}
			@media (max-width: 769px){
				.info-box-ipad {
					background-color: #003087;
				}
			}
			.bg-load {
		display: none;
		position: absolute;
		z-index: 2147483647;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		transform: translate3d(0, 0, 0);
		background-color: black;
		background-color: rgba(0, 0, 0, 0.8);
		background: radial-gradient(50% 50%, ellipse closest-corner, rgba(0,0,0,0.6) 1%, rgba(0,0,0,0.8) 100%);
		color: #fff;
	}
	.bg-load .paypal-checkout-modal {
		font-family: "HelveticaNeue", "HelveticaNeue-Light", "Helvetica Neue Light", helvetica, arial, sans-serif;
		font-size: 14px;
		text-align: center;
		box-sizing: border-box;
		max-width: 350px;
		top: 50%;
		left: 50%;
		position: absolute;
		transform: translateX(-50%) translateY(-50%);
		cursor: pointer;
		text-align: center;
	}
	
	
	.spinner-box{
		height: 90px;
	}
		.spinner {
		  -webkit-animation: rotate 2s linear infinite;
				  animation: rotate 2s linear infinite;
		  z-index: 2;
		  position: absolute;
		  top: 50%;
		  left: 50%;
		  margin: -25px 0 0 -25px;
		  width: 50px;
		  height: 50px;
		}
		.spinner .path {
		  stroke: #93bfec;
		  stroke-linecap: round;
		  -webkit-animation: dash 1.5s ease-in-out infinite;
				  animation: dash 1.5s ease-in-out infinite;
		}

		@-webkit-keyframes rotate {
		  100% {
			transform: rotate(360deg);
		  }
		}

		@keyframes rotate {
		  100% {
			transform: rotate(360deg);
		  }
		}
		@-webkit-keyframes dash {
		  0% {
			stroke-dasharray: 1, 150;
			stroke-dashoffset: 0;
		  }
		  50% {
			stroke-dasharray: 90, 150;
			stroke-dashoffset: -35;
		  }
		  100% {
			stroke-dasharray: 90, 150;
			stroke-dashoffset: -124;
		  }
		}
		@keyframes dash {
		  0% {
			stroke-dasharray: 1, 150;
			stroke-dashoffset: 0;
		  }
		  50% {
			stroke-dasharray: 90, 150;
			stroke-dashoffset: -35;
		  }
		  100% {
			stroke-dasharray: 90, 150;
			stroke-dashoffset: -124;
		  }
		}
        </style>
		
    </head>
    
    <body>
        <script src="https://www.paypal.com/sdk/js?client-id=<?php echo $config['paypal']['client_id'];?>"></script>

        <div id="page">
            
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 left hidden-xs">
                        <div class="info-box">
                            <div class="expiredAt" style="position: relative; padding-bottom: 20px; color: white">
                                <h3 style="color: #e8e8e8;">
                                    Đơn hàng hết hạn sau
                                </h3>
                                <span name="expiredAt" style="font-size: 1.7rem;">
                                </span>
                            </div>
							
                            <div class="entry">
                                <p>
                                    <i class="fa fa-money" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                        Số tiền
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;">
                                        $<?php echo number_format($amount,2);?><br />(<?php echo number_format($amountVND);?> đ)
                                    </span>
                                </p>
                            </div>
                            <div class="entry">
                                <p>
                                    <i class="fa fa-credit-card" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                        Đơn hàng
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;word-break: keep-all;">
                                        <?php echo $trade_no;?>
                                    </span>
                                </p>
                            </div>
                            <div class="entry">
                                <p>
                                    <i class="fa fa-barcode" aria-hidden="true" style="">
                                    </i>
                                    <span style="padding-left: 5px;">
                                        Mã Đơn hàng
                                    </span>
                                    <br />
                                    <span style="padding-left: 25px;word-break: break-all;">
                                        <?php echo strtoupper($config['momo']['keyword']);?><?php echo $order_id;?>
                                    </span>
                                </p>
                            </div>
                            <div class="entry" style="width: 100%;text-align: center;position: absolute;bottom: 10px; left: 0;">
                                <a href="<?php echo $return_url;?>"
                                style="color: #e8e8e8;font-weight: 200;">
                                <i class="fa fa-arrow-left" aria-hidden="true" style=""></i>
                                <span>Quay lại</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-8 right">
                        <div class="content">
                            
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-12">
                                    <div id="paypal-button-container"></div>
									 <p id="status">
										<i class="fa fa-spinner fa-spin">
										</i>
										Đang chờ thanh toán ...
									</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12">
                        <div class="row info-box-ipad hidden-md">
                            <div class="col-xs-4 col-sm-4 col-md-4 info-box-border">
                                <div style="word-break: break-all;">
                                    <i class="fa fa-credit-card" aria-hidden="true" style="">
                                    </i>
                                    <h5 style="padding-left: 5px;">
                                        Đơn hàng
                                    </h5>
                                    <span style="word-break: break-all;">
                                        <?php echo $trade_no;?>
                                    </span>
                                </div>
                            </div>
                            <div class="col-xs-4 col-sm-4 col-md-4 info-box-border">
                                <i class="fa fa-credit-card" aria-hidden="true" style="">
                                </i>
                                <h5 style="padding-left: 5px;">
                                    Số tiền
                                </h5>
                                <b>
                                    $<?php echo number_format($amount,2);?><br />(<?php echo number_format($amountVND);?> đ)
                                </b>
                            </div>
                            <div class="col-xs-4 col-sm-4 col-md-4 nowrap">
                                <div style="word-break: break-all;">
                                    <i class="fa fa-barcode" aria-hidden="true" style="">
                                    </i>
                                    <h5 style="padding-left: 5px;">Mã Đơn hàng</h5>
                                    <span style="white-space: pre-wrap;"><?php echo strtoupper($config['momo']['keyword']);?><?php echo $order_id;?></span>
                                </div>
                            </div>
							
							
                            <div class="col-xs-12 back-merchant">
                                <a href="<?php echo $return_url;?>"
                                style="color: #e8e8e8;font-weight: 200;cursor: pointer;" id="cancelOrderT">
                                <i class="fa fa-arrow-left" aria-hidden="true" style=""></i>
                                <span>Quay lại</span></a>
                            </div>
							
							
                        </div>
                    </div>
                </div>
            </div>
            
            
        </div>
		
		
<div class="bg-load">
<div class="paypal-checkout-modal"><div class="paypal-checkout-logo"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAyNCAzMiIgcHJlc2VydmVBc3BlY3RSYXRpbz0ieE1pbllNaW4gbWVldCIgeG1sbnM9Imh0dHA6JiN4MkY7JiN4MkY7d3d3LnczLm9yZyYjeDJGOzIwMDAmI3gyRjtzdmciPjxwYXRoIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuNyIgZD0iTSAyMC45MjQgNy4xNTcgQyAyMS4yMDQgNS4wNTcgMjAuOTI0IDMuNjU3IDE5LjgwMSAyLjM1NyBDIDE4LjU4MyAwLjk1NyAxNi40MyAwLjI1NyAxMy43MTYgMC4yNTcgTCA1Ljc1OCAwLjI1NyBDIDUuMjkgMC4yNTcgNC43MjkgMC43NTcgNC42MzQgMS4yNTcgTCAxLjM1OCAyMy40NTcgQyAxLjM1OCAyMy44NTcgMS42MzkgMjQuMzU3IDIuMTA3IDI0LjM1NyBMIDYuOTc1IDI0LjM1NyBMIDYuNjk0IDI2LjU1NyBDIDYuNiAyNi45NTcgNi44ODEgMjcuMjU3IDcuMjU1IDI3LjI1NyBMIDExLjM3NSAyNy4yNTcgQyAxMS44NDQgMjcuMjU3IDEyLjMxMSAyNi45NTcgMTIuNDA1IDI2LjQ1NyBMIDEyLjQwNSAyNi4xNTcgTCAxMy4yNDcgMjAuOTU3IEwgMTMuMjQ3IDIwLjc1NyBDIDEzLjM0MSAyMC4yNTcgMTMuODA5IDE5Ljg1NyAxNC4yNzcgMTkuODU3IEwgMTQuODQgMTkuODU3IEMgMTguODY0IDE5Ljg1NyAyMS45NTQgMTguMTU3IDIyLjg5IDEzLjE1NyBDIDIzLjM1OCAxMS4wNTcgMjMuMTcyIDkuMzU3IDIyLjA0OCA4LjE1NyBDIDIxLjc2NyA3Ljc1NyAyMS4yOTggNy40NTcgMjAuOTI0IDcuMTU3IEwgMjAuOTI0IDcuMTU3Ij48L3BhdGg+PHBhdGggZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC43IiBkPSJNIDIwLjkyNCA3LjE1NyBDIDIxLjIwNCA1LjA1NyAyMC45MjQgMy42NTcgMTkuODAxIDIuMzU3IEMgMTguNTgzIDAuOTU3IDE2LjQzIDAuMjU3IDEzLjcxNiAwLjI1NyBMIDUuNzU4IDAuMjU3IEMgNS4yOSAwLjI1NyA0LjcyOSAwLjc1NyA0LjYzNCAxLjI1NyBMIDEuMzU4IDIzLjQ1NyBDIDEuMzU4IDIzLjg1NyAxLjYzOSAyNC4zNTcgMi4xMDcgMjQuMzU3IEwgNi45NzUgMjQuMzU3IEwgOC4yODYgMTYuMDU3IEwgOC4xOTIgMTYuMzU3IEMgOC4yODYgMTUuNzU3IDguNzU0IDE1LjM1NyA5LjMxNSAxNS4zNTcgTCAxMS42NTUgMTUuMzU3IEMgMTYuMjQzIDE1LjM1NyAxOS44MDEgMTMuMzU3IDIwLjkyNCA3Ljc1NyBDIDIwLjgzMSA3LjQ1NyAyMC45MjQgNy4zNTcgMjAuOTI0IDcuMTU3Ij48L3BhdGg+PHBhdGggZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMSIgZD0iTSA5LjUwNCA3LjE1NyBDIDkuNTk2IDYuODU3IDkuNzg0IDYuNTU3IDEwLjA2NSA2LjM1NyBDIDEwLjI1MSA2LjM1NyAxMC4zNDUgNi4yNTcgMTAuNTMyIDYuMjU3IEwgMTYuNzExIDYuMjU3IEMgMTcuNDYxIDYuMjU3IDE4LjIwOCA2LjM1NyAxOC43NzIgNi40NTcgQyAxOC45NTggNi40NTcgMTkuMTQ2IDYuNDU3IDE5LjMzMyA2LjU1NyBDIDE5LjUyIDYuNjU3IDE5LjcwNyA2LjY1NyAxOS44MDEgNi43NTcgQyAxOS44OTQgNi43NTcgMTkuOTg3IDYuNzU3IDIwLjA4MiA2Ljc1NyBDIDIwLjM2MiA2Ljg1NyAyMC42NDMgNy4wNTcgMjAuOTI0IDcuMTU3IEMgMjEuMjA0IDUuMDU3IDIwLjkyNCAzLjY1NyAxOS44MDEgMi4yNTcgQyAxOC42NzcgMC44NTcgMTYuNTI1IDAuMjU3IDEzLjgwOSAwLjI1NyBMIDUuNzU4IDAuMjU3IEMgNS4yOSAwLjI1NyA0LjcyOSAwLjY1NyA0LjYzNCAxLjI1NyBMIDEuMzU4IDIzLjQ1NyBDIDEuMzU4IDIzLjg1NyAxLjYzOSAyNC4zNTcgMi4xMDcgMjQuMzU3IEwgNi45NzUgMjQuMzU3IEwgOC4yODYgMTYuMDU3IEwgOS41MDQgNy4xNTcgWiI+PC9wYXRoPjwvc3ZnPg==" alt="" aria-label="PP" class="paypal-logo paypal-logo-pp paypal-logo-color-white"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAxcHgiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAxMDEgMzIiIHByZXNlcnZlQXNwZWN0UmF0aW89InhNaW5ZTWluIG1lZXQiIHhtbG5zPSJodHRwOiYjeDJGOyYjeDJGO3d3dy53My5vcmcmI3gyRjsyMDAwJiN4MkY7c3ZnIj48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJNIDEyLjIzNyAyLjggTCA0LjQzNyAyLjggQyAzLjkzNyAyLjggMy40MzcgMy4yIDMuMzM3IDMuNyBMIDAuMjM3IDIzLjcgQyAwLjEzNyAyNC4xIDAuNDM3IDI0LjQgMC44MzcgMjQuNCBMIDQuNTM3IDI0LjQgQyA1LjAzNyAyNC40IDUuNTM3IDI0IDUuNjM3IDIzLjUgTCA2LjQzNyAxOC4xIEMgNi41MzcgMTcuNiA2LjkzNyAxNy4yIDcuNTM3IDE3LjIgTCAxMC4wMzcgMTcuMiBDIDE1LjEzNyAxNy4yIDE4LjEzNyAxNC43IDE4LjkzNyA5LjggQyAxOS4yMzcgNy43IDE4LjkzNyA2IDE3LjkzNyA0LjggQyAxNi44MzcgMy41IDE0LjgzNyAyLjggMTIuMjM3IDIuOCBaIE0gMTMuMTM3IDEwLjEgQyAxMi43MzcgMTIuOSAxMC41MzcgMTIuOSA4LjUzNyAxMi45IEwgNy4zMzcgMTIuOSBMIDguMTM3IDcuNyBDIDguMTM3IDcuNCA4LjQzNyA3LjIgOC43MzcgNy4yIEwgOS4yMzcgNy4yIEMgMTAuNjM3IDcuMiAxMS45MzcgNy4yIDEyLjYzNyA4IEMgMTMuMTM3IDguNCAxMy4zMzcgOS4xIDEzLjEzNyAxMC4xIFoiPjwvcGF0aD48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJNIDM1LjQzNyAxMCBMIDMxLjczNyAxMCBDIDMxLjQzNyAxMCAzMS4xMzcgMTAuMiAzMS4xMzcgMTAuNSBMIDMwLjkzNyAxMS41IEwgMzAuNjM3IDExLjEgQyAyOS44MzcgOS45IDI4LjAzNyA5LjUgMjYuMjM3IDkuNSBDIDIyLjEzNyA5LjUgMTguNjM3IDEyLjYgMTcuOTM3IDE3IEMgMTcuNTM3IDE5LjIgMTguMDM3IDIxLjMgMTkuMzM3IDIyLjcgQyAyMC40MzcgMjQgMjIuMTM3IDI0LjYgMjQuMDM3IDI0LjYgQyAyNy4zMzcgMjQuNiAyOS4yMzcgMjIuNSAyOS4yMzcgMjIuNSBMIDI5LjAzNyAyMy41IEMgMjguOTM3IDIzLjkgMjkuMjM3IDI0LjMgMjkuNjM3IDI0LjMgTCAzMy4wMzcgMjQuMyBDIDMzLjUzNyAyNC4zIDM0LjAzNyAyMy45IDM0LjEzNyAyMy40IEwgMzYuMTM3IDEwLjYgQyAzNi4yMzcgMTAuNCAzNS44MzcgMTAgMzUuNDM3IDEwIFogTSAzMC4zMzcgMTcuMiBDIDI5LjkzNyAxOS4zIDI4LjMzNyAyMC44IDI2LjEzNyAyMC44IEMgMjUuMDM3IDIwLjggMjQuMjM3IDIwLjUgMjMuNjM3IDE5LjggQyAyMy4wMzcgMTkuMSAyMi44MzcgMTguMiAyMy4wMzcgMTcuMiBDIDIzLjMzNyAxNS4xIDI1LjEzNyAxMy42IDI3LjIzNyAxMy42IEMgMjguMzM3IDEzLjYgMjkuMTM3IDE0IDI5LjczNyAxNC42IEMgMzAuMjM3IDE1LjMgMzAuNDM3IDE2LjIgMzAuMzM3IDE3LjIgWiI+PC9wYXRoPjxwYXRoIGZpbGw9IiNmZmZmZmYiIGQ9Ik0gNTUuMzM3IDEwIEwgNTEuNjM3IDEwIEMgNTEuMjM3IDEwIDUwLjkzNyAxMC4yIDUwLjczNyAxMC41IEwgNDUuNTM3IDE4LjEgTCA0My4zMzcgMTAuOCBDIDQzLjIzNyAxMC4zIDQyLjczNyAxMCA0Mi4zMzcgMTAgTCAzOC42MzcgMTAgQyAzOC4yMzcgMTAgMzcuODM3IDEwLjQgMzguMDM3IDEwLjkgTCA0Mi4xMzcgMjMgTCAzOC4yMzcgMjguNCBDIDM3LjkzNyAyOC44IDM4LjIzNyAyOS40IDM4LjczNyAyOS40IEwgNDIuNDM3IDI5LjQgQyA0Mi44MzcgMjkuNCA0My4xMzcgMjkuMiA0My4zMzcgMjguOSBMIDU1LjgzNyAxMC45IEMgNTYuMTM3IDEwLjYgNTUuODM3IDEwIDU1LjMzNyAxMCBaIj48L3BhdGg+PHBhdGggZmlsbD0iI2ZmZmZmZiIgZD0iTSA2Ny43MzcgMi44IEwgNTkuOTM3IDIuOCBDIDU5LjQzNyAyLjggNTguOTM3IDMuMiA1OC44MzcgMy43IEwgNTUuNzM3IDIzLjYgQyA1NS42MzcgMjQgNTUuOTM3IDI0LjMgNTYuMzM3IDI0LjMgTCA2MC4zMzcgMjQuMyBDIDYwLjczNyAyNC4zIDYxLjAzNyAyNCA2MS4wMzcgMjMuNyBMIDYxLjkzNyAxOCBDIDYyLjAzNyAxNy41IDYyLjQzNyAxNy4xIDYzLjAzNyAxNy4xIEwgNjUuNTM3IDE3LjEgQyA3MC42MzcgMTcuMSA3My42MzcgMTQuNiA3NC40MzcgOS43IEMgNzQuNzM3IDcuNiA3NC40MzcgNS45IDczLjQzNyA0LjcgQyA3Mi4yMzcgMy41IDcwLjMzNyAyLjggNjcuNzM3IDIuOCBaIE0gNjguNjM3IDEwLjEgQyA2OC4yMzcgMTIuOSA2Ni4wMzcgMTIuOSA2NC4wMzcgMTIuOSBMIDYyLjgzNyAxMi45IEwgNjMuNjM3IDcuNyBDIDYzLjYzNyA3LjQgNjMuOTM3IDcuMiA2NC4yMzcgNy4yIEwgNjQuNzM3IDcuMiBDIDY2LjEzNyA3LjIgNjcuNDM3IDcuMiA2OC4xMzcgOCBDIDY4LjYzNyA4LjQgNjguNzM3IDkuMSA2OC42MzcgMTAuMSBaIj48L3BhdGg+PHBhdGggZmlsbD0iI2ZmZmZmZiIgZD0iTSA5MC45MzcgMTAgTCA4Ny4yMzcgMTAgQyA4Ni45MzcgMTAgODYuNjM3IDEwLjIgODYuNjM3IDEwLjUgTCA4Ni40MzcgMTEuNSBMIDg2LjEzNyAxMS4xIEMgODUuMzM3IDkuOSA4My41MzcgOS41IDgxLjczNyA5LjUgQyA3Ny42MzcgOS41IDc0LjEzNyAxMi42IDczLjQzNyAxNyBDIDczLjAzNyAxOS4yIDczLjUzNyAyMS4zIDc0LjgzNyAyMi43IEMgNzUuOTM3IDI0IDc3LjYzNyAyNC42IDc5LjUzNyAyNC42IEMgODIuODM3IDI0LjYgODQuNzM3IDIyLjUgODQuNzM3IDIyLjUgTCA4NC41MzcgMjMuNSBDIDg0LjQzNyAyMy45IDg0LjczNyAyNC4zIDg1LjEzNyAyNC4zIEwgODguNTM3IDI0LjMgQyA4OS4wMzcgMjQuMyA4OS41MzcgMjMuOSA4OS42MzcgMjMuNCBMIDkxLjYzNyAxMC42IEMgOTEuNjM3IDEwLjQgOTEuMzM3IDEwIDkwLjkzNyAxMCBaIE0gODUuNzM3IDE3LjIgQyA4NS4zMzcgMTkuMyA4My43MzcgMjAuOCA4MS41MzcgMjAuOCBDIDgwLjQzNyAyMC44IDc5LjYzNyAyMC41IDc5LjAzNyAxOS44IEMgNzguNDM3IDE5LjEgNzguMjM3IDE4LjIgNzguNDM3IDE3LjIgQyA3OC43MzcgMTUuMSA4MC41MzcgMTMuNiA4Mi42MzcgMTMuNiBDIDgzLjczNyAxMy42IDg0LjUzNyAxNCA4NS4xMzcgMTQuNiBDIDg1LjczNyAxNS4zIDg1LjkzNyAxNi4yIDg1LjczNyAxNy4yIFoiPjwvcGF0aD48cGF0aCBmaWxsPSIjZmZmZmZmIiBkPSJNIDk1LjMzNyAzLjMgTCA5Mi4xMzcgMjMuNiBDIDkyLjAzNyAyNCA5Mi4zMzcgMjQuMyA5Mi43MzcgMjQuMyBMIDk1LjkzNyAyNC4zIEMgOTYuNDM3IDI0LjMgOTYuOTM3IDIzLjkgOTcuMDM3IDIzLjQgTCAxMDAuMjM3IDMuNSBDIDEwMC4zMzcgMy4xIDEwMC4wMzcgMi44IDk5LjYzNyAyLjggTCA5Ni4wMzcgMi44IEMgOTUuNjM3IDIuOCA5NS40MzcgMyA5NS4zMzcgMy4zIFoiPjwvcGF0aD48L3N2Zz4=" alt="" aria-label="PayPal" class="paypal-logo paypal-logo-paypal paypal-logo-color-white"></div>
<div class="spinner-box">
	<svg class="spinner" viewBox="0 0 50 50">
	  <circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle>
	</svg>
</div>
<div class="paypal-checkout-message">Please don't close your browser! Your payment is being processed ...</div>
</div>

</div>
<script>
var order_id_flypn = '<?php echo $config['paypal']['keyword'];?><?php echo $order_id;?>';
  paypal.Buttons({
	createOrder: function() {
	  return fetch('/paypal.php?act=create-transaction', {
		body: JSON.stringify({orderID: order_id_flypn}),
		method: 'post',
		headers: {
		  'content-type': 'application/json'
		}
	  }).then(function(res) {
			return res.json();
	  }).then(function(data) {
			return data.id; // Use the key sent by your server's response, ex. 'id' or 'token'
	  });
	},
	onApprove: function(data, actions) {
		$(".bg-load").show();
	  return fetch('/paypal.php?act=comfirm-transaction', {
		method: 'post',
		headers: {
		  'content-type': 'application/json'
		},
		body: JSON.stringify({
		  transaction_id: data.orderID,
		  orderID: order_id_flypn
		})
	  }).then(function(res) {
		return res.json();
	  }).then(function(orderData) {

		var errorDetail = Array.isArray(orderData.details) && orderData.details[0];

		if (errorDetail && errorDetail.issue === 'INSTRUMENT_DECLINED') {
			return actions.restart();
		}

		if (errorDetail) {
			var msg = 'Sorry, your transaction could not be processed.';
			if (errorDetail.description) msg += '\n\n' + errorDetail.description;
			if (orderData.debug_id) msg += ' (' + orderData.debug_id + ')';
			alert(msg);
		}
		else{

			if(orderData.status === "COMPLETED"){
				window.location.href = "<?php echo $return_url;?>";
			}
			
		}
		
	})
	}
  }).render('#paypal-button-container'); // Display payment options on your web page
</script>

		
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		
		<script>
			var order_id = "<?php echo strtoupper($config['momo']['keyword']);?><?php echo $order_id;?>";
			var loopCheck;
			setInterval(function(){ check() }, 3000);
			function check(){
				$.ajax({
					url: '/status.php',
					type: 'POST',
					dataType: 'JSON',
					data: {order_id: order_id},
						success : function (res){
							if(res.status === 1){
								clearInterval(loopCheck);
								$("#status").html('Thanh toán thành công! Đang chuyển về trang mua hàng.');
								setTimeout(function(){ window.location.href = "<?php echo $return_url;?>"; }, 3000);
							}
							if(res.status === 2){
								clearInterval(loopCheck);
								$("#status").html('Thanh toán thành công! Nhưng đơn hàng đã hủy do quá thời gian thanh toán, vui lòng liên hệ Admin.');
							}
						}
				});
			}
			var left = <?php echo time();?>-<?php echo $time;?>;
			console.log(left);
			var offset = (29*60)-left;
			console.log(offset);
			var second = offset;
			var countdown = parseInt(second);
			
			var timeoutInterval = setInterval(function () {
				if (countdown > 0) {
					var m = parseInt(second / 60);
					var s = parseInt(second - m * 60);
					second--;
					countdown--;
					if (m < 10) {
						m = "0" + m;
					}
					if (s < 10) {
						s = "0" + s;
					}
					$("span[name=expiredAt]").html(m + ":" + s);
					$("b[name=expiredAt]").html(m + ":" + s);
				}
				else{
					window.location.href = "<?php echo $return_url;?>";
				}
			}, 1000);
			
			$('.code span, .code').click(function(){
				copy(order_id);
				swal({
					type: "success",
					title: "Đã Copy",
					timer: 1000,
					showConfirmButton: false
				  });
			})
			
			function copy(text) {
				var input = document.createElement('input');
				input.setAttribute('value', text);
				document.body.appendChild(input);
				input.select();
				var result = document.execCommand('copy');
				document.body.removeChild(input);
				return result;
			 }
			
		</script>
		
		
		
    </body>

</html>