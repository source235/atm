<?php
	error_reporting(0);
	include('config.php');
	include('functions.php');

	if(!isset($_GET['sig']) or $_GET['sig'] == ""){
		header("Location: https://speed4g.xyz/");
		exit;
	}
	$sig = $_GET['sig'];
	$paygate = $_GET['paygate'];
	
	if(!isset($config[$paygate])){
		header("Location: https://speed4g.xyz/");
		exit;
	}
	
	$key = $config[$paygate][getKey($paygate)];
	$decrypt_string = decrypt($sig,$key);

	if($decrypt_string == ""){
		header("Location: https://speed4g.xyz/");
		exit;
	}
	
	$order = json_decode($decrypt_string);
	
	if(!isset($order->total_amount) or !isset($order->trade_no) or !isset($order->order_id) or !isset($order->return_url) ){
		header("Location: https://speed4g.xyz/");
		exit;
	}
	
	$amount = (int)$order->total_amount/100;
	$amount = round($amount);
	if($paygate == "paypal"){
		$amountVND = $amount;
		$amount =  round($amount/22500,2);
	}
		
	$return_url = $order->return_url;
	$notify_url = $order->notify_url;
	$trade_no = $order->trade_no;
	//print_r($trade_no);
	$order_id = $order->order_id;

	@mkdir('tttmp/speed'.$order_id);
	
	if(!file_exists('tttmp/speed'.$order_id.'/status.log')){
		file_put_contents('tttmp/speed'.$order_id.'/status.log',0);
	}
	
	file_put_contents('tttmp/speed'.$order_id.'/trade_no.log',$trade_no);
	
	file_put_contents('tttmp/speed'.$order_id.'/price.log',$amount);
	
	if(!file_exists('tttmp/speed'.$order_id.'/time.log')){
		file_put_contents('tttmp/speed'.$order_id.'/time.log',time());
	}
	
	$time = file_get_contents('tttmp/speed'.$order_id.'/time.log');
	$status = file_get_contents('tttmp/speed'.$order_id.'/status.log');
	if($status == "1"){
		header("Location: ".$return_url);
		exit;
	}
	
	if($paygate == "momo")
		include('gate/momo.php');
	if($paygate == "paypal")
		include('gate/paypal.php');
	if($paygate == "casso")
		include('gate/casso.php');
	
	
?>
