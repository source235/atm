<?php
//momosv3
$config['momo']['token'] = "mfyFyncdcJDvVv6csDqvIwURhepwjtjKRTA6D9TCiW2ndTP5xa";
$config['momo']['signatire'] = "46b695c17e25e176b18dd222d562ba7f1a255a0ce3e9666f2de07e7de6898d71";
$config['momo']['phone'] = "0978442525";
$config['momo']['ipn'] = "https://cloudfast.vn/api/v1/guest/payment/notify/MomoSv3/GTouLOx0";
$config['momo']['keyword'] = "cf";

//paypal
$config['paypal']['secret_Key'] = "";
$config['paypal']['client_id'] = "";
$config['paypal']['ipn'] = "";
$config['paypal']['keyword'] =  "";

// casso
$config['casso']['api_Key'] = "nghitretrau";
$config['casso']['ACCOUNT_NO'] = "104875731757";
$config['casso']['BANK_ID'] = "970415";
$config['casso']['ACCOUNT_NAME'] = "Nguyễn Văn Nghị";
$config['casso']['ipn'] = "https://speed4g.xyz/api/v1/guest/payment/notify/Casso/JLbMnoqU";
$config['casso']['keyword'] = "speed";

