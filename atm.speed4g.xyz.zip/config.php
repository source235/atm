<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "pr9gZr91IdlGNLX31TEZczOVfUTh2CDLNMZcPxhkTxMZEgDBtC";
const SIGNATIRE = "6b78f31ff98bccc71d8e8add2942c8e99f0ea57b7585faf1357fe6e9cb0071e1";
const PHONE = "1017212861";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/ATM/OmpmlsB6";