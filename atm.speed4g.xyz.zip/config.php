<?php
//momosv3
$config['momo']['token'] = "qr7eyP9eeIY3jU5Y7xCoUWpcKVnLHHys4s5Tfh6RdXrwHCYv2v";
$config['momo']['signatire'] = "62f29163917ec6f6f6404e8971dbcb4731464bee8e5a1050eb702cdcb065ed74";
$config['momo']['phone'] = "0333725953";
$config['momo']['ipn'] = "https://speed4g.xyz/api/v1/guest/payment/notify/MomoSv3/2YofxjQ0";
$config['momo']['keyword'] = "";

//paypal
$config['paypal']['secret_Key'] = "";
$config['paypal']['client_id'] = "";
$config['paypal']['ipn'] = "";
$config['paypal']['keyword'] =  "";

// casso
$config['casso']['api_Key'] = "nguyenvannghiiubuithiquyen";
$config['casso']['ACCOUNT_NO'] = "104875731757";
$config['casso']['BANK_ID'] = "970415";
$config['casso']['ACCOUNT_NAME'] = "NGUYỄN VĂN NGHỊ";
$config['casso']['ipn'] = "https://speed4g.xyz/api/v1/guest/payment/notify/Casso/JLbMnoqU";
$config['casso']['keyword'] = "";

