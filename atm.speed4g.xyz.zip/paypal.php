<?php
require_once __DIR__ . '/vendor/autoload.php'; 
include('config.php');
include('functions.php');


use PayPalCheckoutSdk\Core\PayPalHttpClient;
//use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Core\ProductionEnvironment;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;

$act = $_GET['act'];



if($act == "create-transaction"){
	$postData = file_get_contents('php://input');
	$postData = json_decode($postData);
	
	$orderID = $postData->orderID;
	if($orderID == "")
		exit;
	
	$price = file_get_contents('tttmp/'.$orderID.'/price.log');
	$trade_no = file_get_contents('tttmp/'.$orderID.'/trade_no.log');
	if($price == "")
		exit;
	$currentcy_code = "USD";

	$environment = new ProductionEnvironment($config['paypal']['client_id'], $config['paypal']['secret_Key']);
	$client = new PayPalHttpClient($environment);
	$request = new OrdersCreateRequest();
	$request->prefer('return=representation');
	$request->body = [
						 "intent" => "CAPTURE",
						 "purchase_units" => [[
							 "reference_id" => $orderID,
							 "amount" => [
								 "value" => number_format($price,2),
								 "currency_code" => $currentcy_code
							 ]
						 ]],
						 "application_context" => [
							"shipping_preference" => "NO_SHIPPING",
							"brand_name" => "FLYPN Network",
							"cancel_url" => "https://go.flypn.net/",
							"return_url" => "https://go.flypn.net/"
						 ] 
					 ];

	try {
		// Call API with your client and get a response for your call
		$response = $client->execute($request);
		
		// If call returns body in response, you can get the deserialized version from the result attribute of the response
		if(isset($response->result->id)){
			file_put_contents('tttmp/'.$orderID.'/paypal_transaction_id.log',$response->result->id);
			
			//$this->MCommon->update(['paypal_transaction_id'=>$response->result->id],'orders',['id'=>$orderID]);
			echo json_encode($response->result);
		}
	}catch (HttpException $ex) {
		echo $ex->statusCode;
		print_r($ex->getMessage());
	}
}

if($act == "comfirm-transaction"){
	
	$postData = file_get_contents('php://input');
	$postData = json_decode($postData);
	

	
	$orderID = $postData->orderID;
	if($orderID == "")
		exit;
	
	$transaction_id = $postData->transaction_id;
	if($transaction_id == "")
		exit;

	$price = file_get_contents('tttmp/'.$orderID.'/price.log');
	$trade_no = file_get_contents('tttmp/'.$orderID.'/trade_no.log');
	$paypal_transaction_id = file_get_contents('tttmp/'.$orderID.'/paypal_transaction_id.log');
		
	
	

	$environment = new ProductionEnvironment($config['paypal']['client_id'], $config['paypal']['secret_Key']);
	$client = new PayPalHttpClient($environment);
	$request = new OrdersCaptureRequest($transaction_id);
	$request->prefer('return=representation');

	try {

		$response = $client->execute($request);
		if(isset($response->result)){
			if($response->result->status == "COMPLETED" and $response->result->purchase_units[0]->amount->value == $price){
				$dataPost = array(
					"token" => $config['paypal']['secret_Key'],
					"trade_no" => $trade_no,
					"out_trade_no" => $paypal_transaction_id,
					);

				$ch = curl_init($config['paypal']['ipn']);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
				curl_setopt($ch, CURLOPT_TIMEOUT,30);
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'POST');
				curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($dataPost));
				$output = curl_exec($ch);
				curl_close($ch);
				
				//echo http_build_query($dataPost);
				$res = $output;
				
				
				if($res == "success"){
					file_put_contents('tttmp/'.$orderID.'/status.log',1);
				}
			}
			
		}
		
		echo json_encode($response->result);
		
	}catch (HttpException $ex) {
		echo $ex->statusCode;
		print_r($ex->getMessage());
	}
}