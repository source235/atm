<?php
    include('config.php');
    include('functions.php');
	//Tiền tố điền trước mã đơn hàng để tạo mã cho khách hàng chuyển tiền
	//Không phân biệt hoa thường  : DH123, dh123, Dh123, dH123 đều dc.
	$MEMO_PREFIX = $config['casso']['keyword'];

	//Key bảo mật đã cấu hình bên Casso để chứng thực request
	$HEADER_SECURE_TOKEN = $config['casso']['api_Key'];

    $order_id_tmp = false;
    $price = 0;
	payment_handler($order_id_tmp, $price);

    $order_id = $config['casso']['keyword'].$order_id_tmp;
    $check  = file_get_contents('tttmp/'.$order_id.'/trade_no.log');
    $amount = (int)file_get_contents('tttmp/'.$order_id.'/price.log');
    if ($check && $price >= $amount) {
    	$dataPost = array(
    		"token"        => $config['casso']['api_Key'],
    		"trade_no"     => $check,
    		"out_trade_no" => $order_id_tmp,
    	);
    
    	$ch = curl_init($config['casso']['ipn']);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,false);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
    	curl_setopt($ch, CURLOPT_TIMEOUT,30);
    	curl_setopt($ch, CURLOPT_CUSTOMREQUEST,'POST');
    	curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($dataPost));
    	$output = curl_exec($ch);
    	curl_close($ch);
        if ($output == 'success') {
            file_put_contents('tttmp/'.$order_id.'/status.log',1);   
        }
    }
	die();

	function payment_handler(&$order_id_tmp, &$price){
		global $MEMO_PREFIX,$HEADER_SECURE_TOKEN;
		$txtBody = file_get_contents('php://input');
		$jsonBody = json_decode($txtBody); //convert JSON into array
		if (!$txtBody || !$jsonBody){
			echo "Request thiếu body";
			die();
		}
		if ($jsonBody->error != 0){
			echo "Có lỗi xay ra ở phía Casso";
			die();
		}

		$headers = getHeader();

		if ( $headers['Secure-Token'] != $HEADER_SECURE_TOKEN ) {
			echo("Thiếu Secure Token hoặc secure token không khớp");
			die(); 
		}

        $DataArr = array();
		foreach ($jsonBody->data as $key => $transaction) {
			$des = $transaction ->description;
			$order_id = parse_order_id($des);
			if (is_null($order_id)) {
				continue;
			} else {
			    $order_id_tmp = $order_id;
                $order_id = $MEMO_PREFIX.$order_id;
                $price = $transaction->amount;
			}
		}
	}

	function parse_order_id($des){
		global $MEMO_PREFIX;
		$re = '/'.$MEMO_PREFIX.'\d+/mi';
		preg_match_all($re, $des, $matches, PREG_SET_ORDER, 0);

		if (count($matches) == 0 )
			return null;
		// Print the entire match result
		$orderCode = $matches[0][0];
		
		$prefixLength = strlen($MEMO_PREFIX);

		$orderId = intval(substr($orderCode, $prefixLength ));
		return $orderId ;

	}
	function getHeader(){
		$headers = array();

        $copy_server = array(
            'CONTENT_TYPE'   => 'Content-Type',
            'CONTENT_LENGTH' => 'Content-Length',
            'CONTENT_MD5'    => 'Content-Md5',
        );

        foreach ($_SERVER as $key => $value) {
            if (substr($key, 0, 5) === 'HTTP_') {
                $key = substr($key, 5);
                if (!isset($copy_server[$key]) || !isset($_SERVER[$key])) {
                    $key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', $key))));
                    $headers[$key] = $value;
                }
            } elseif (isset($copy_server[$key])) {
                $headers[$copy_server[$key]] = $value;
            }
        }

        if (!isset($headers['Authorization'])) {
            if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
                $headers['Authorization'] = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
            } elseif (isset($_SERVER['PHP_AUTH_USER'])) {
                $basic_pass = isset($_SERVER['PHP_AUTH_PW']) ? $_SERVER['PHP_AUTH_PW'] : '';
                $headers['Authorization'] = 'Basic ' . base64_encode($_SERVER['PHP_AUTH_USER'] . ':' . $basic_pass);
            } elseif (isset($_SERVER['PHP_AUTH_DIGEST'])) {
                $headers['Authorization'] = $_SERVER['PHP_AUTH_DIGEST'];
            }
        }

        return $headers;
	}

?>