<?php
const DOMAINV2B = "speed4g.xyz";
const KEYWORD = ""; //viết thường
const TOKEN = "bPPVlzMmQfVQM8OWncvHZgCyUAWC3f5Dd5eWeHbdsIDK58jqFK";
const SIGNATIRE = "dcedb602a4616111239f57553bf2882f3c1abc427a4be94265d011ded8ed7647";
const PHONE = "1017212861";
const WEBHOOK = "https://speed4g.xyz/api/v1/guest/payment/notify/ATM/n62TXVQH";